﻿namespace ApiOpWebE_C.OperationResults
{
    public class Urls
    {

       static public string UrlSaveImages = "wwwroot/uploads";
    }
}
