﻿namespace ApiOpWebE_C.OperationResults
{
    public class MessageResult
    {

        static public string IsFind = "Is Find";
        static public string IsNotFind = "Is Not Find";
        static public string DataNull = "Context data cannot be null";
        static public string DeletedSuccessfully = "Item deleted successfully";


        public static class CrudMessages
        {
            public static string CreatedSuccessfully = "Item created successfully";
            public static string RetrievedSuccessfully = "Items retrieved successfully";
            public static string UpdatedSuccessfully = "Item updated successfully";
            public static string DeletedSuccessfully = "Item deleted successfully";
            public static string OperationFailed = "Operation failed";
        }

      

        public static class CrudFiles
        {
            public const string NotUpload = "Failed to upload the file.";
            public const string filesAreNotAllowed = "File type is not allowed.";
            public const string DeletedSuccessfully = "File deleted successfully.";
            public const string ReplacedSuccessfully = "File Replaced successfully.";
            public const string FileNotFound = "File not found.";
            public const string InvalidFileName = "Invalid file name.";
            public const string ErrorWhileDeleting = "An error occurred while deleting the file.";
        }

        public static class OrderProductStatus
        {
            public const string Pending = "Pending";             
            public const string Processing = "Processing";       
            public const string Shipped = "Shipped";            
            public const string OutForDelivery = "Out for Delivery";
            public const string Delivered = "Delivered";        
            public const string Cancelled = "Cancelled";         
            public const string Returned = "Returned";           
            public const string Failed = "Delivery Failed";      
        }

        public static class MessageRequests
        {
            public const string NoRequestsFound = "No requests found.";
            public const string UserNotFound = "User not found.";
            public const string SavingFailed = "Saving failed.";
        }



    }



}
