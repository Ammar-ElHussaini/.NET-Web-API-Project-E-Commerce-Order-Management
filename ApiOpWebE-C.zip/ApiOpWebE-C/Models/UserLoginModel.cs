﻿using System.ComponentModel.DataAnnotations;

namespace ApiOpWebE_C.Models
{
    public class UserLoginModel
    {

        [Required]
        public string Username { get; set; }

        [Required]
        public string Passwword { get; set; }
        public string email { get; set; }
        public string Role { get; set; }


     

    }

}
