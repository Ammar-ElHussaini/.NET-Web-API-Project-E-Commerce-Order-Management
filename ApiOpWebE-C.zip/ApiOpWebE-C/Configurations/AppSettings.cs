﻿public class AppSettings
{
    public JwtSettings JwtSettings { get; set; }
    public ConnectionStrings ConnectionStrings { get; set; }
    public Logging Logging { get; set; }
    public string AllowedHosts { get; set; }
}

public class JwtSettings
{
    public string SecretKey { get; set; }
    public string Issuer { get; set; }
    public string Audience { get; set; }
    public int ExpiresInMinutes { get; set; }
}

public class ConnectionStrings
{
    public string DefaultConnection { get; set; }
}

public class Logging
{
    public LogLevel LogLevel { get; set; }
}

public class LogLevel
{
    public string Default { get; set; }
    public string Microsoft_AspNetCore { get; set; }
}
