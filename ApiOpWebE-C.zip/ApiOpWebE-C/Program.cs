﻿using ApiOpWebE_C.Models.DB;
using ApiOpWebE_C.Service_Layer.AccountsService;
using ApiOpWebE_C.Service_Layer.FilesSevices;
using ApiOpWebE_C.Service_Layer.JwtTokenService;
using ApiOpWebE_C.Service_Layer.OrdersOperathion;
using ApiOpWebE_C.Service_Layer.ProductsAdminService;
using Data_Access_Layer.ProjectRoot.Core.Interfaces;
using Data_Access_Layer.ProjectRoot.Infrastructure.Repositories;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace ApiOpWebE_C
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Configuration
            builder.Services.Configure<AppSettings>(builder.Configuration.GetSection("AppSettings"));
            var appSettings = builder.Configuration.GetSection("AppSettings").Get<AppSettings>();

            // Database Configuration
            builder.Services.AddDbContext<LapShopContext>(options =>
                options.UseSqlServer(appSettings.ConnectionStrings.DefaultConnection));

            // Identity Configuration
            builder.Services.AddIdentity<IdentityUser, IdentityRole>()
                .AddEntityFrameworkStores<LapShopContext>()
                .AddDefaultTokenProviders();

            // Service Registration
            builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();
            builder.Services.AddScoped<ClJwtToken>();
            builder.Services.AddScoped<AccountsService>();
            builder.Services.AddTransient<CrudOpAdminProduct>();
            builder.Services.AddTransient<ImageFileOperations>();
            builder.Services.AddTransient<OrderProcessor>();

            // Authentication Configuration
            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(options =>
            {
                options.RequireHttpsMetadata = true;
                options.SaveToken = true;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = appSettings.JwtSettings.Issuer,
                    ValidAudience = appSettings.JwtSettings.Audience,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(appSettings.JwtSettings.SecretKey)),
                    ClockSkew = TimeSpan.Zero
                };
            });

            // CORS Configuration
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll",
                    policy =>
                    {
                        policy.AllowAnyOrigin()
                              .AllowAnyHeader()
                              .AllowAnyMethod();
                    });
            });

            // MVC and API Configuration
            builder.Services.AddControllers();

            // Swagger Configuration
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            // App Building
            var app = builder.Build();

            // Middleware Pipeline
            app.UseStaticFiles();
            app.UseCors("AllowAll");

            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();
            app.UseAuthentication();
            app.UseAuthorization();

            app.MapControllers();
            app.Run();
        }
    }
}