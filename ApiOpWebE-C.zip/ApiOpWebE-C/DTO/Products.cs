﻿namespace ApiOpWebE_C.DTO
{
    public class Products
    {
        public string ItemName { get; set; } = null!;

        public decimal SalesPrice { get; set; }

        public string CategoryName { get; set; } = null!;


        public string? ImageName { get; set; }
        public string? UrlImage { get; set; }

        public int ItemId { get; set; }

        public int CategoryId { get; set; }
    }
}
