﻿using System.ComponentModel.DataAnnotations;

namespace ApiOpWebE_C.DTO
{
    public class DTOOrderRequest
    {
      
        public string UserId { get; set; }
        public string ProductID { get; set; }
        public DateTime RequestDate { get; set; } = DateTime.Now;

    }
}
