﻿using ApiOpWebE_C.Models.DB;
using ApiOpWebE_C.OperationResults;
using ApiOpWebE_C.Service_Layer.ProductsAdminService;
using Data_Access_Layer.ProjectRoot.Core.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiOpWebE_C.Controllers.Products
{

    [Authorize(Roles = "Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsAdminControlle : ControllerBase
    {

        private readonly IUnitOfWork _unitOfWork;
        private readonly CrudOpAdminProduct _crudOpAdminProduct;
        public ProductsAdminControlle(IUnitOfWork unitOfWork, CrudOpAdminProduct crudOpAdminProduct)
        {
            _unitOfWork = unitOfWork;
            _crudOpAdminProduct = crudOpAdminProduct;
        }

        #region Read
        [HttpGet("Products")]
        public IActionResult Products()
        {
            var products = _crudOpAdminProduct.Products();

            if (products == null)
            {
                return NotFound(MessageResult.CrudMessages.OperationFailed);
            }

            return Ok(products);
        }
        [HttpGet("Products/{IdItem}")]
        public IActionResult Products(int IdItem)
        {
            var products = _crudOpAdminProduct.GetProductById(IdItem);

            if (products == null)
            {
                return NotFound(MessageResult.CrudMessages.OperationFailed);
            }

            return Ok(products.Context);
        }

        [HttpGet("ProductsPagination/{skip}/{take}")]
        public IActionResult ProductsPagination(int skip, int take)
        {
            var products = _crudOpAdminProduct.ProductsPagination(skip, take);

            if (products == null && products.IsSuccess == false)
            {
                return NotFound(MessageResult.IsNotFind);
            }

            return Ok(products.ContextList);
        }

        [HttpGet("ProductsByCategory/{categoryId}/{take}")]
        public IActionResult ProductsByCategory(int categoryId, int take)
        {
            var products = _crudOpAdminProduct.ProductsByCategory(categoryId, take);

            if (products == null && products.IsSuccess == false)
            {
                return NotFound(MessageResult.IsNotFind);
            }

            return Ok(products);
        }

        [HttpGet("SimilarProducts/{categoryId}/{price}/{take}")]
        public async Task<IActionResult> SimilarProducts(int categoryId, decimal price, int take)
        {
            var products = _crudOpAdminProduct.SimilarProducts(categoryId, price, take);

            if (products == null && products.IsSuccess == false)
            {
                return NotFound(MessageResult.IsNotFind);
            }

            return Ok(products);
        }

        #endregion
        #region Add Products 
        [HttpGet("NewProducts")]
        public IActionResult NewProducts([FromBody] TbItem tbItem)
        {
            var products = _crudOpAdminProduct.NewProducts(tbItem);

            if (products == null && products.IsSuccess == false)
            {
                return NotFound(MessageResult.IsNotFind);
            }

            return Ok();
        }

        #endregion
        #region Update
        [HttpPut("UpdateProducts/{itemId}")]
        public async Task<IActionResult> UpdateProducts(int itemId, TbItem tbItem)
        {
            var products = _crudOpAdminProduct.UpdateProducts(itemId, tbItem);

            if (products == null && products.IsSuccess == false)
            {
                return NotFound(MessageResult.IsNotFind);
            }

            return Ok();
        }
        #endregion
        #region Delete
        [HttpDelete("DeleteProduct/{itemId}")]
        public async Task<IActionResult> DeleteProduct(int itemId)
        {
            var products = _crudOpAdminProduct.DeleteProduct(itemId);


            if (products == null && products.IsSuccess == false)
            {
                return NotFound(MessageResult.IsNotFind);
            }

            return Ok(products);

        }
        #endregion


    }
}
