﻿using ApiOpWebE_C.Models.DB;
using Data_Access_Layer.ProjectRoot.Core.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ApiOpWebE_C.Controllers.Products
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsUserControlle : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;

        public ProductsUserControlle(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet("Products")]
        public IActionResult Products()
        {
            var products = _unitOfWork.Repository<VwItemCategory>().GetAllAsync().Result;

            var randomProducts = products
                .OrderBy(p => Guid.NewGuid())
                .Take(20)
                .ToList();

            return Ok(randomProducts);
        }

        [HttpGet("ProductsPagination/{skip}/{take}")]
        public IActionResult ProductsPagination(int skip, int take)
        {
            var products = _unitOfWork.Repository<VwItemCategory>().GetAllAsync().Result;

            var pagedProducts = products
                .Skip(skip)
                .Take(take)
                .ToList();

            return Ok(pagedProducts);
        }

        [HttpGet("ProductsByCategory/{categoryId}/{take}")]
        public IActionResult ProductsByCategory(int categoryId, int take)
        {
            var products = _unitOfWork.Repository<VwItemCategory>().GetAllAsync().Result;

            var filteredProducts = products
                .Where(p => p.CategoryId == categoryId)
                .OrderBy(p => Guid.NewGuid())
                .Take(take)
                .ToList();

            return Ok(filteredProducts);
        }

        [HttpGet("SimilarProducts/{categoryId}/{price}/{take}")]
        public async Task<IActionResult> SimilarProducts(int categoryId, decimal price, int take)
        {
            var products = await _unitOfWork.Repository<VwItemCategory>().GetAllAsync();

            var similarProducts = products
                .Where(p => p.CategoryId == categoryId && p.SalesPrice >= price * 0.8m && p.SalesPrice <= price * 1.2m)
                .OrderBy(p => Guid.NewGuid())
                .Take(take)
                .ToList();

            return Ok(similarProducts);
        }
    }
}
