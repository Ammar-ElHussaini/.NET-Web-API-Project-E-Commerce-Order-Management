﻿using ApiOpWebE_C.DTO;
using ApiOpWebE_C.Models;
using ApiOpWebE_C.OperationResults;
using ApiOpWebE_C.Service_Layer.AccountsService;
using ApiOpWebE_C.Service_Layer.JwtTokenService;
using Data_Access_Layer.ProjectRoot.Core.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ApiOpWebE_C.Controllers
{



    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {

        private readonly IUnitOfWork _unitOfWork;
        private readonly ClJwtToken _ClJwtToken;
        private readonly AccountsService _AccountsService;
        private readonly UserManager<IdentityUser> _userManager;

        public AuthController(IUnitOfWork unitOfWork, ClJwtToken ClJwtToken , UserManager<IdentityUser> userManager , AccountsService AccountsService)
        {
            _unitOfWork = unitOfWork;
            _ClJwtToken = ClJwtToken;
            _userManager = userManager;
            _AccountsService = AccountsService;
        }

    


        [HttpPost("RegisterUser")]
        public async Task<IActionResult> RegisterUser([FromBody] UserLoginModel userDto )
        {


            if (!ModelState.IsValid)
            {
                var allErrors = ModelState.Values.SelectMany(v => v.Errors)
                                          .Select(e => e.ErrorMessage)                    
                                          .ToList();

                return BadRequest(allErrors);
            }

            CreationResult<IdentityUser> user = _AccountsService.RegisterUser(userDto).Result;

            if (user.IsSuccess == false) { return BadRequest(MessageResult.IsFind); }

            string token = _ClJwtToken.GenerateJwtToken(userDto);
            return Ok(token); 
        }

        [HttpPost("LoginUser")]
        public async Task<IActionResult> LoginUser([FromBody] UserLoginModel userDto)
        {

            if (!ModelState.IsValid)
            {
                var allErrors = ModelState.Values.SelectMany(v => v.Errors)
                                          .Select(e => e.ErrorMessage)
                                          .ToList();

                return BadRequest(allErrors);
            }
            CreationResult<IdentityUser>  user = _AccountsService.LoginUser(userDto).Result;

            if (user.IsSuccess == false) { return BadRequest(MessageResult.IsNotFind); }

            string token = _ClJwtToken.GenerateJwtToken(userDto);
            return Ok(token);

        }




    }
}