﻿using ApiOpWebE_C.DTO;
using ApiOpWebE_C.OperationResults;
using ApiOpWebE_C.Service_Layer.OrdersOperathion;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ApiOpWebE_C.Controllers.Orders
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly OrderProcessor _creatOrder;

        public OrderController(OrderProcessor creatOrder)
        {
            _creatOrder = creatOrder;
        }

        [Authorize]
        [HttpPost("Orders")]
        public IActionResult CreateOrders([FromBody] List<DTOOrderRequest> orders)
        {
            var order = _creatOrder.CreateOrderProducts(orders);

            if (!order.IsSuccess)
                return BadRequest(MessageResult.CrudMessages.OperationFailed);

            return Ok(MessageResult.OrderProductStatus.Pending);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("ConfirmOrders")]
        public IActionResult ShipOrders([FromBody] List<int> orderIds)
        {
            var order = _creatOrder.MarkOrdersAsShipped(orderIds);

            if (!order.IsSuccess)
                return BadRequest(MessageResult.CrudMessages.OperationFailed);

            return Ok(MessageResult.OrderProductStatus.Shipped);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost("GetAllOrders")]
        public IActionResult GetOrders()
        {
            var order = _creatOrder.GetAllOrders();

            if (!order.IsSuccess)
                return BadRequest(MessageResult.CrudMessages.OperationFailed);

            return Ok(order.Context.ToList());
        }

        [Authorize]
        [HttpPost("CancelOrder/{idOrder}")]
        public IActionResult CancelOrder(int idOrder)
        {
            var order = _creatOrder.CancelOrder(idOrder);

            if (!order.IsSuccess)
                return BadRequest(MessageResult.CrudMessages.OperationFailed);

            return Ok(MessageResult.OrderProductStatus.Cancelled);
        }
    }
}
