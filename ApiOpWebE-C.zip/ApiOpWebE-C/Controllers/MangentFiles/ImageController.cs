﻿using ApiOpWebE_C.OperationResults;
using ApiOpWebE_C.Service_Layer.FilesSevices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;


[Authorize (Roles = "Admin")]
[ApiController]
[Route("api/[controller]")]
public class ImageController : ControllerBase
{
    private readonly ImageFileOperations _imageFileOperations;

    public ImageController(ImageFileOperations imageFileOperations)
    {
        _imageFileOperations = imageFileOperations;
    }

    [HttpPost("image")]
    public IActionResult UploadImage(IFormFile file)
    {
        if (file == null)
        {
            return BadRequest(MessageResult.CrudFiles.NotUpload);
        }

        var creationResult = _imageFileOperations.UploadImage(file);

        if (!creationResult.IsSuccess)
        {
            return BadRequest(creationResult.Message);
        }

        return Ok(creationResult.Context.ImageName);
    }

    [HttpDelete("image/{imageName}")]
    public IActionResult DeleteImage(string imageName)
    {
        var result = _imageFileOperations.DeleteImageByName(imageName);
        if (!result.IsSuccess)
        {
            return BadRequest(result.Message);
        }

        return Ok(result.Message);
    }

    [HttpPut("image/{imageName}")]
    public IActionResult UpdateImage(string imageName, IFormFile file)
    {
        var result = _imageFileOperations.ReplaceImage(imageName, file);
        if (!result.IsSuccess)
        {
            return BadRequest(result.Message);
        }

        return Ok(result.Message);
    }
}
