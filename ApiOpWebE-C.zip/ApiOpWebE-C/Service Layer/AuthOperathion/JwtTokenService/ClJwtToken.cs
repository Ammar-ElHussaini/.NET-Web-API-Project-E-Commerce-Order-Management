﻿using ApiOpWebE_C.Models;
using Data_Access_Layer.ProjectRoot.Core.Interfaces;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ApiOpWebE_C.Service_Layer.JwtTokenService
{
    public class ClJwtToken
    {
        private readonly AppSettings _AppSettings;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<IdentityUser> _IdentityUser2;


        public ClJwtToken (IOptions<AppSettings> appSettings , RoleManager<IdentityRole> IdentityUser, UserManager<IdentityUser> IdentityUser2)
        {
            _AppSettings = appSettings.Value;
            _roleManager = IdentityUser;
            _IdentityUser2 = IdentityUser2;

        }

        public string GenerateJwtToken(UserLoginModel userLoginModelToken)
        {
            var userId = _roleManager.FindByIdAsync(userLoginModelToken.Role).Result ;  // إذا كنت تستخدم الـ Username كـ User ID، يمكن تغييره حسب الحاجة
            var userRoles = userId.Name;
            var claims = new List<Claim>
    {
        new Claim("username", userLoginModelToken.Username), 
        new Claim("role", userRoles) ,       
        new Claim("Email", userLoginModelToken.email)          
    };

            // إعداد المفتاح السري للتوقيع
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_AppSettings.JwtSettings.SecretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            // إنشاء الـ JWT Token
            var token = new JwtSecurityToken(
                issuer: _AppSettings.JwtSettings.Issuer,        
                audience: _AppSettings.JwtSettings.Audience,    // الجهة المستهدفة
                claims: claims,                                // الـ Claims الخاصة بالـ Token
                expires: DateTime.Now.AddMinutes(_AppSettings.JwtSettings.ExpiresInMinutes), // مدة الصلاحية
                signingCredentials: creds                      // التوقيع باستخدام المفتاح السري
            );

            // تحويل الـ JWT Token إلى String وإرجاعه
            string tokenend = new JwtSecurityTokenHandler().WriteToken(token);
            return tokenend;
        }

        public ClaimsPrincipal GetPrincipalFromToken(string token, string secretKey)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(secretKey);

            var validationParameters = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = false,
                ValidateAudience = false,
                ClockSkew = TimeSpan.Zero 
            };

            try
            {
                var principal = tokenHandler.ValidateToken(token, validationParameters, out SecurityToken validatedToken);

                if (validatedToken is JwtSecurityToken jwtToken &&
                    jwtToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
                {
                    return principal;
                }

                return null;
            }
            catch
            {
                return null;
            }
        }

    }
}
