﻿using ApiOpWebE_C.DTO;
using ApiOpWebE_C.Models;
using ApiOpWebE_C.OperationResults;
using ApiOpWebE_C.Service_Layer.JwtTokenService;
using Data_Access_Layer.ProjectRoot.Core.Interfaces;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ApiOpWebE_C.Service_Layer.AccountsService
{
    public class AccountsService
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;  
        private readonly SignInManager<IdentityUser> _signInManager;

        public AccountsService(UserManager<IdentityUser> userManager,
                               RoleManager<IdentityRole> roleManager,  
                               SignInManager<IdentityUser> signInManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;  // تعيين RoleManager
            _signInManager = signInManager;
        }

        public async Task<CreationResult<IdentityUser>> RegisterUser(UserLoginModel userDto )
        {
            if (userDto == null)
            {
                return new CreationResult<IdentityUser>
                {
                    IsSuccess = false,
                    Message = MessageResult.DataNull
                };
            }

            #region IsUserIsExixts

            var normalizedInput = userDto.Username.ToUpper();
            var existingUser =  _userManager.Users
                .FirstOrDefaultAsync(u => u.UserName == userDto.Username || u.Email == userDto.email);

            if (existingUser.Result != null)
            {
                return new CreationResult<IdentityUser>()
                {
                    IsSuccess = false,
                    Message = MessageResult.IsFind 
                };
            }


            #endregion

            #region CreatUser

            IdentityUser newUser = new IdentityUser()
            {
                Id = Guid.NewGuid().ToString(),
                UserName = userDto.Username,
                Email = userDto.email,
                PasswordHash = userDto.Passwword
            };

            var result =  _userManager.CreateAsync(newUser, userDto.Passwword).Result;


            if (!result.Succeeded )
            {
                var errors = result.Errors.Select(e => e.Description).ToList();
                return new CreationResult<IdentityUser>
                {
                    Errors = errors,
                    IsSuccess = false
                };
            }

            var UserRole = _roleManager.FindByIdAsync(userDto.Role).Result.ToString();
            var resultAdd = _userManager.AddToRoleAsync(newUser, UserRole).Result;
            #endregion

            return new CreationResult<IdentityUser>
            {
                IsSuccess = true,
                Context = newUser
            };

        }
        public async Task<CreationResult<IdentityUser>> LoginUser(UserLoginModel userDto)
        {

            

            if (userDto == null)
            {
                return new CreationResult<IdentityUser>
                {
                    IsSuccess = false,
                    Message = MessageResult.DataNull
                };
            }


            #region IsUserIsExixts

            var normalizedInput = userDto.Username.ToUpper();
            var existingUser = _userManager.Users
                .FirstOrDefaultAsync(u => u.UserName == userDto.Username || u.Email == userDto.email).Result;


            if (existingUser == null)
            {
              return  new CreationResult<IdentityUser>
                {

                    IsSuccess = false
                                    ,
                    Message = MessageResult.IsNotFind
                };

            }

            var result = _signInManager.PasswordSignInAsync(existingUser, userDto.Passwword, false, false).Result;
            if (result.Succeeded)
            {
              return  new CreationResult<IdentityUser>
                {
                    Context = existingUser,
                    IsSuccess = true
                    ,
                    Role = _userManager.GetRolesAsync(existingUser).Result.ToString()
                };

            }


            return new CreationResult<IdentityUser>
            {
                IsSuccess = false,
                Message = MessageResult.IsNotFind
            }; 
            #endregion


  
         
        }


    }

   


}


