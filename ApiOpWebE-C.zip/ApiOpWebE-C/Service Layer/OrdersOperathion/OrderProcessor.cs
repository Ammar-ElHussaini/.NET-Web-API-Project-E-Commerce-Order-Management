﻿using ApiOpWebE_C.DTO;
using ApiOpWebE_C.Models.DB;
using ApiOpWebE_C.OperationResults;
using Data_Access_Layer.ProjectRoot.Core.Interfaces;
using Microsoft.AspNetCore.Identity;

namespace ApiOpWebE_C.Service_Layer.OrdersOperathion
{
    public class OrderProcessor
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly UserManager<IdentityUser> _userManager;

        public OrderProcessor(IUnitOfWork unitOfWork, UserManager<IdentityUser> userManager)
        {
            _unitOfWork = unitOfWork;
            _userManager = userManager;
        }

        public float GetTotalPriceForUser(List<OrderRequest> requests)
        {
            return requests.Sum(r => r.Price);
        }

        public  CreationResult<List<OrderRequest>> CreateOrderProducts(List<DTOOrderRequest> requests)
        {
            if (requests == null || requests.Count == 0)
                return new CreationResult<List<OrderRequest>>
                {
                    IsSuccess = false,
                    Message = MessageResult.MessageRequests.NoRequestsFound
                };

            var user =  _userManager.FindByIdAsync(requests.First().UserId).Result;

            if (user == null)
                return new CreationResult<List<OrderRequest>>
                {
                    IsSuccess = false,
                    Message = MessageResult.MessageRequests.UserNotFound
                };

            List<OrderRequest> orderRequests = new();

            foreach (var request in requests)
            {
                int ProductID = int.Parse(request.ProductID);
                var product =  _unitOfWork.Repository<TbItem>().GetByIdAsync(ProductID).Result;

                if (product == null)
                    continue; // Ignore if the product is not found

                OrderRequest order = new()
                {
                    UserName = user.UserName,
                    ProductID = product.ItemId.ToString(),
                    ProductName = product.ItemName,
                    Price = float.Parse(product.PurchasePrice.ToString()),
                    UserId = user.Id,
                    User = user,
                    State = MessageResult.OrderProductStatus.Pending
                };

                orderRequests.Add(order);
                 _unitOfWork.Repository<OrderRequest>().AddAsync(order);
            }

            var result =  _unitOfWork.CompleteAsync().Result;

            if (result <= 0)
            {
                return new CreationResult<List<OrderRequest>>
                {
                    IsSuccess = false,
                    Message = MessageResult.MessageRequests.SavingFailed
                };
            }

            return new CreationResult<List<OrderRequest>>
            {
                IsSuccess = true,
            };
        }

        public  CreationResult<bool> MarkOrdersAsShipped(List<int> orderIds)
        {
            if (orderIds == null || orderIds.Count == 0)
            {
                return new CreationResult<bool>
                {
                    IsSuccess = false,
                    Message = MessageResult.CrudMessages.OperationFailed
                };
            }

            var orders =  _unitOfWork.Repository<OrderRequest>()
                .GetAllAsync(o => orderIds.Contains(o.Id)).Result;

            if (orders == null || !orders.Any())
            {
                return new CreationResult<bool>
                {
                    IsSuccess = false,
                    Message = MessageResult.CrudMessages.OperationFailed
                };
            }

            foreach (var order in orders)
            {
                if (order.State != MessageResult.OrderProductStatus.Pending)
                    continue;

                order.State = MessageResult.OrderProductStatus.Shipped;
                _unitOfWork.Repository<OrderRequest>().Update(order);
            }

            var result =  _unitOfWork.CompleteAsync().Result;

            if (result <= 0)
            {
                return new CreationResult<bool>
                {
                    IsSuccess = false,
                    Message = MessageResult.CrudMessages.OperationFailed
                };
            }

            return new CreationResult<bool>
            {
                IsSuccess = true,
                Message = MessageResult.CrudMessages.CreatedSuccessfully
            };
        }

        public CreationResult<List<OrderRequest>> GetAllOrders()
        {
            var orders =  _unitOfWork.Repository<OrderRequest>().GetAllAsync().Result;

            if (orders == null || !orders.Any())
            {
                return new CreationResult<List<OrderRequest>>
                {
                    IsSuccess = false,
                    Message = MessageResult.MessageRequests.NoRequestsFound
                };
            }

            return new CreationResult<List<OrderRequest>>
            {
                IsSuccess = true,
                Context = orders.ToList()
            };
        }

        public CreationResult<OrderRequest> CancelOrder(int id)
        {
            try
            {
                var order =  _unitOfWork.Repository<OrderRequest>().GetByIdAsync(id).Result;

                if (order == null)
                {
                    return new CreationResult<OrderRequest>
                    {
                        IsSuccess = false,
                        Message = MessageResult.OrderProductStatus.Failed,
                    };
                }

                order.State = MessageResult.OrderProductStatus.Cancelled;
                _unitOfWork.Repository<OrderRequest>().Update(order);
                 _unitOfWork.CompleteAsync();

                return new CreationResult<OrderRequest>
                {
                    IsSuccess = true,
                };
            }
            catch (OperationCanceledException)
            {
                return new CreationResult<OrderRequest>
                {
                    IsSuccess = false,
                    Message = MessageResult.OrderProductStatus.Cancelled,
                };
            }
        }
    }
}
