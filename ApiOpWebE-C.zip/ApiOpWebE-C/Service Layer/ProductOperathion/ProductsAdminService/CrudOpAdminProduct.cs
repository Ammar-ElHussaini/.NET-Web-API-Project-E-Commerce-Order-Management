﻿using ApiOpWebE_C.DTO;
using ApiOpWebE_C.Models.DB;
using ApiOpWebE_C.OperationResults;
using Data_Access_Layer.ProjectRoot.Core.Interfaces;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace ApiOpWebE_C.Service_Layer.ProductsAdminService
{
    public class CrudOpAdminProduct
    {
        private readonly IUnitOfWork _unitOfWork;

        public CrudOpAdminProduct(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        #region ReadProduct
        public CreationResult<Products> Products()
        {
            var products = _unitOfWork.Repository<VwItemCategory>().GetAllAsync().Result;

            var randomProducts = products
                .OrderBy(p => Guid.NewGuid())
                .Take(20)
                .ToList();

            var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
            var baseUrl = "https://localhost:7138/uploads/";

            var productsDtos = randomProducts.Select(p =>
            {
                string? imageUrl = null;

                // التأكد من وجود صورة للمنتج
                if (!string.IsNullOrEmpty(p.ImageName))
                {
                    var imageFullPath = Path.Combine(uploadsPath, p.ImageName);
                    if (System.IO.File.Exists(imageFullPath))
                    {
                        imageUrl = $"{baseUrl}{p.ImageName}";
                    }
                }

                // بناء كائن ProductDTO
                return new Products
                {
                    ItemId = p.ItemId,
                    ItemName = p.ItemName,
                    SalesPrice = p.SalesPrice,
                    CategoryName = p.CategoryName,
                    CategoryId = p.CategoryId,
                    ImageName = p.ImageName,
                    UrlImage = imageUrl
                };
            }).ToList();

            if (randomProducts.Count == 0)
                return new CreationResult<Products>
                {
                    IsSuccess = false,
                    Message = MessageResult.IsNotFind
                };

            return new CreationResult<Products>
            {
                IsSuccess = true,
                ContextList = productsDtos
            };
        }

        public CreationResult<Products> GetProductById(int itemId)
        {
            var product = _unitOfWork.Repository<VwItemCategory>()
                .GetAllAsync().Result
                .FirstOrDefault(p => p.ItemId == itemId);

            if (product == null)
            {
                return new CreationResult<Products>
                {
                    IsSuccess = false,
                    Message = MessageResult.IsNotFind
                };
            }

            var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
            var baseUrl = "https://localhost:7138/uploads/";

            string? imageUrl = null;

            if (!string.IsNullOrEmpty(product.ImageName))
            {
                var imageFullPath = Path.Combine(uploadsPath, product.ImageName);
                if (System.IO.File.Exists(imageFullPath))
                {
                    imageUrl = $"{baseUrl}{product.ImageName}";
                }
            }

            var productDto = new Products
            {
                ItemId = product.ItemId,
                ItemName = product.ItemName,
                SalesPrice = product.SalesPrice,
                CategoryName = product.CategoryName,
                CategoryId = product.CategoryId,
                ImageName = product.ImageName,
                UrlImage = imageUrl
            };

            return new CreationResult<Products>
            {
                IsSuccess = true,
                Context = productDto
            };
        }
            
        public CreationResult<Products> ProductsPagination(int skip, int take)
        {
            var products = _unitOfWork.Repository<VwItemCategory>().GetAllAsync().Result;

          

            var pagedProducts = products
                .Skip(skip)
                .Take(take)
                .ToList();

            var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
            var baseUrl = "https://localhost:7138/uploads/";

            var productsDtos = pagedProducts.Select(p =>
            {
                string? imageUrl = null;

                if (!string.IsNullOrEmpty(p.ImageName))
                {
                    var imageFullPath = Path.Combine(uploadsPath, p.ImageName);
                    if (System.IO.File.Exists(imageFullPath))
                    {
                        imageUrl = $"{baseUrl}{p.ImageName}";
                    }
                }

                return new Products
                {
                    ItemId = p.ItemId,
                    ItemName = p.ItemName,
                    SalesPrice = p.SalesPrice,
                    CategoryName = p.CategoryName,
                    CategoryId = p.CategoryId,
                    ImageName = p.ImageName,
                    UrlImage = imageUrl
                };
            }).ToList();

           

            if (pagedProducts.Count == 0)
                return new CreationResult<Products> { IsSuccess = true, Message = MessageResult.IsNotFind };


            return new CreationResult<Products> { IsSuccess = true, ContextList = productsDtos };
        }

        public CreationResult<Products> ProductsByCategory(int categoryId, int take)
        {
            var products = _unitOfWork.Repository<VwItemCategory>().GetAllAsync().Result;

            var filteredProducts = products
                .Where(p => p.CategoryId == categoryId)
                .OrderBy(p => Guid.NewGuid())
                .Take(take)
                .ToList();

            var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
            var baseUrl = "https://localhost:7138/uploads/";

            var productsDtos = filteredProducts.Select(p =>
            {
                string? imageUrl = null;

                if (!string.IsNullOrEmpty(p.ImageName))
                {
                    var imageFullPath = Path.Combine(uploadsPath, p.ImageName);
                    if (System.IO.File.Exists(imageFullPath))
                    {
                        imageUrl = $"{baseUrl}{p.ImageName}";
                    }
                }

                // بناء كائن ProductDTO
                return new Products
                {
                    ItemId = p.ItemId,
                    ItemName = p.ItemName,
                    SalesPrice = p.SalesPrice,
                    CategoryName = p.CategoryName,
                    CategoryId = p.CategoryId,
                    ImageName = p.ImageName,
                    UrlImage = imageUrl
                };
            }).ToList();

            if (filteredProducts.Count == 0)
                return new CreationResult<Products> { IsSuccess = true, Message = MessageResult.IsNotFind };


            return new CreationResult<Products> { IsSuccess = true, ContextList = productsDtos };
        }

        public CreationResult<Products> SimilarProducts(int categoryId, decimal price, int take)
        {
            var products =  _unitOfWork.Repository<VwItemCategory>().GetAllAsync().Result;

            var similarProducts = products
                .Where(p => p.CategoryId == categoryId && p.SalesPrice >= price * 0.8m && p.SalesPrice <= price * 1.2m)
                .OrderBy(p => Guid.NewGuid())
                .Take(take)
                .ToList();

            var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
            var baseUrl = "https://localhost:7138/uploads/";

            var productsDtos = similarProducts.Select(p =>
            {
                string? imageUrl = null;

                if (!string.IsNullOrEmpty(p.ImageName))
                {
                    var imageFullPath = Path.Combine(uploadsPath, p.ImageName);
                    if (System.IO.File.Exists(imageFullPath))
                    {
                        imageUrl = $"{baseUrl}{p.ImageName}";
                    }
                }

                // بناء كائن ProductDTO
                return new Products
                {
                    ItemId = p.ItemId,
                    ItemName = p.ItemName,
                    SalesPrice = p.SalesPrice,
                    CategoryName = p.CategoryName,
                    CategoryId = p.CategoryId,
                    ImageName = p.ImageName,
                    UrlImage = imageUrl
                };
            }).ToList();

            if (similarProducts.Count == 0)
                return new CreationResult<Products> { IsSuccess = true, Message = MessageResult.IsNotFind };


            return new CreationResult<Products> { IsSuccess = true, ContextList = productsDtos };
        }

        #endregion 

        #region Add Products 
        [HttpGet("NewProducts")]
        public CreationResult<TbItem> NewProducts([FromBody] TbItem tbItem)
        {
            if (tbItem == null)
            {
                return new CreationResult<TbItem>
                {
                    IsSuccess = false,
                    Message = MessageResult.DataNull
                };
            }



            var product = _unitOfWork.Repository<TbItem>().AddAsync(tbItem);
            var result =  _unitOfWork.CompleteAsync().Result;

            if (product == null || result <= 0)
                return new CreationResult<TbItem>
                {
                    IsSuccess = false,
                    Message = MessageResult.IsNotFind
                };

            return new CreationResult<TbItem>
            {
                IsSuccess = true,
                Message = MessageResult.CrudMessages.CreatedSuccessfully
            };
        }

        #endregion

        #region Update Product
        [HttpPut("UpdateProducts/{itemId}")]
        public CreationResult<TbItem> UpdateProducts(int itemId, TbItem tbItem)
        {

            if (tbItem == null && tbItem.ItemName == null )
            {
                return new CreationResult<TbItem>
                {
                    IsSuccess = false,
                    Message = MessageResult.DataNull
                };
            }

            var existingItem = _unitOfWork.Repository<TbItem>().GetByIdAsync(itemId).Result;
            if (existingItem == null)
                return new CreationResult<TbItem>
                {
                    IsSuccess = false,
                    Message = MessageResult.IsNotFind
                };

            existingItem.ItemName = tbItem.ItemName;
            existingItem.Description = tbItem.Description;
            existingItem.SalesPrice = tbItem.SalesPrice;
            existingItem.CategoryId = tbItem.CategoryId;

            _unitOfWork.Repository<TbItem>().Update(existingItem);
            var Result = _unitOfWork.CompleteAsync().Result;


            if (Result <= 0)
            {
                return (new CreationResult<TbItem>
                {
                    IsSuccess = false,
                    Message = MessageResult.CrudMessages.OperationFailed
                });
            }

            return (new CreationResult<TbItem>
            {
                IsSuccess = true,
                Message = MessageResult.CrudMessages.UpdatedSuccessfully
            });
        }
        #endregion

        #region Delete Product
        [HttpDelete("DeleteProduct/{itemId}")]
       public  CreationResult<TbItem> DeleteProduct(int itemId)
            {

            if (itemId == null)
            {
                return new CreationResult<TbItem>
                {
                    IsSuccess = false,
                    Message = MessageResult.DataNull
                };
            }

            var existingItem =  _unitOfWork.Repository<TbItem>().GetByIdAsync(itemId).Result;
            if (existingItem == null)
            {
                return (new CreationResult<TbItem>
                {
                    IsSuccess = false,
                    Message = MessageResult.IsNotFind
                });
            }

            _unitOfWork.Repository<TbItem>().Delete(existingItem);
            var result =  _unitOfWork.CompleteAsync().Result;

            if (result <= 0)
            {
                return (new CreationResult<TbItem>
                {
                    IsSuccess = false,
                    Message = MessageResult.CrudMessages.OperationFailed
                });
            }

            return (new CreationResult<TbItem>
            {
                IsSuccess = true,
                Message = MessageResult.CrudMessages.DeletedSuccessfully,
                Context = existingItem
            });
        }
            #endregion

    }
}
