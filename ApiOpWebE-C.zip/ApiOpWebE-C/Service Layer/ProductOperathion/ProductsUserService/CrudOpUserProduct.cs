﻿using ApiOpWebE_C.DTO;
using ApiOpWebE_C.Models.DB;
using ApiOpWebE_C.OperationResults;

namespace ApiOpWebE_C.Service_Layer.ProductsAdminService
{
    public class CrudOpUserProduct
    {

        private readonly CrudOpAdminProduct _crudOpAdminProduct;
        public CrudOpUserProduct(CrudOpAdminProduct crudOpAdminProduct)
        {
            _crudOpAdminProduct = crudOpAdminProduct;
        }

        #region Read Pr
        public CreationResult<Products> GetProducts()
        {
            return _crudOpAdminProduct.Products();
        }

        public CreationResult<Products> ProductsPagination(int skip, int take)
        {
            return _crudOpAdminProduct.ProductsPagination(skip, take);
        }

        public CreationResult<Products> ProductsByCategory(int categoryId, int take)
        {
            return _crudOpAdminProduct.ProductsByCategory(categoryId, take);
        }

        public CreationResult<Products> SimilarProducts(int categoryId, decimal price, int take)
        {
            
                return _crudOpAdminProduct.SimilarProducts(categoryId, price, take);
        }

        #endregion


    }
}
