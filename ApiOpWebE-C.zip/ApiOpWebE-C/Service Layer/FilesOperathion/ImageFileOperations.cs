﻿using ApiOpWebE_C.DTO;
using ApiOpWebE_C.OperationResults;
using Azure.Core;
using Microsoft.AspNetCore.Mvc;

namespace ApiOpWebE_C.Service_Layer.FilesSevices
{
    public class ImageFileOperations
    {
        public CreationResult<Products> UploadImage(IFormFile file )
        {
            if (file == null || file.Length == 0)
                return new CreationResult<Products> { IsSuccess =false , Message = MessageResult.CrudFiles.NotUpload };

            var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp" };
            var extension = Path.GetExtension(file.FileName).ToLowerInvariant();

            if (!allowedExtensions.Contains(extension))
                return new CreationResult<Products> { IsSuccess = false, Message = MessageResult.CrudFiles.filesAreNotAllowed };

            try
            {

              

                var uniqueFileName = $"{Guid.NewGuid()}{extension}";
                var filePath = Path.Combine(Urls.UrlSaveImages, uniqueFileName);

                Products products = new()
                {
                    ImageName = uniqueFileName ,
                };


                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                     file.CopyToAsync(stream);
                }


                return new CreationResult<Products>
                {
                    IsSuccess = true,
                    Context = products

                };
                
                   
                
            }
            catch (Exception ex)
            {
                return new CreationResult<Products>
                {
                    IsSuccess = false,
                    Message = MessageResult.CrudFiles.filesAreNotAllowed
                };
            }
        }

        public CreationResult<Products> UploadImage(IFormFile file, string NameFile)
        {
            if (file == null || file.Length == 0)
                return new CreationResult<Products> { IsSuccess = false, Message = MessageResult.CrudFiles.NotUpload };

            var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp" };
            var extension = Path.GetExtension(file.FileName).ToLowerInvariant();

            if (!allowedExtensions.Contains(extension))
                return new CreationResult<Products> { IsSuccess = false, Message = MessageResult.CrudFiles.filesAreNotAllowed };

            try
            {



                var uniqueFileName = NameFile;
                var filePath = Path.Combine(Urls.UrlSaveImages, uniqueFileName);

                Products products = new()
                {
                    ImageName = uniqueFileName,
                };


                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyToAsync(stream);
                }


                return new CreationResult<Products>
                {
                    IsSuccess = true,
                    Context = products

                };



            }
            catch (Exception ex)
            {
                return new CreationResult<Products>
                {
                    IsSuccess = false,
                    Message = MessageResult.CrudFiles.filesAreNotAllowed
                };
            }
        }
        public CreationResult<Products> DeleteImageByName(string imageName)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(imageName))
                {
                    return new CreationResult<Products>
                    {
                        IsSuccess = false,
                        Message = MessageResult.CrudFiles.InvalidFileName
                    };
                }

                var filePath = Path.Combine(Urls.UrlSaveImages, imageName);

                if (!File.Exists(filePath))
                {
                    return new CreationResult<Products>
                    
                    {
                        IsSuccess = false,
                        Message = MessageResult.CrudFiles.FileNotFound


                    };
                }

                File.Delete(filePath);

                return new CreationResult<Products>
                    
                {
                    IsSuccess = true,
                    Message = MessageResult.CrudFiles.DeletedSuccessfully
                };
            }
            catch (Exception ex)
            {
                return new CreationResult<Products>

                {
                    IsSuccess = false,
                    Message = MessageResult.CrudFiles.ErrorWhileDeleting
                };
            }
        }
        public CreationResult<Products> ReplaceImage(string oldImageName, IFormFile newFile)
        {
          var resultDelete =  DeleteImageByName(oldImageName);

            if (!resultDelete.IsSuccess)
            {
                return new CreationResult<Products>
                {
                    Message = MessageResult.CrudFiles.ErrorWhileDeleting
                };
            }
            
            var resultUpload = UploadImage(newFile, oldImageName);

            if (!resultUpload.IsSuccess)
            {
                return new CreationResult<Products>
                {
                    Message = MessageResult.CrudFiles.NotUpload
                };
            }

            return new CreationResult<Products>
            {
                Message = MessageResult.CrudFiles.ReplacedSuccessfully
            };
        }

    }
}
